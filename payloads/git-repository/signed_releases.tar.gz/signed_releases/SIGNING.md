# Signed Releases

This repository contains GPG-signed annotated Git tags (releases).

All tags in this repository are signed using GPG:
- v1.0.0 - Signed release tag
- v2.0.0 - Signed release tag
- v2.1.0 - Signed release tag

Use `git tag -v <tagname>` to verify signatures.
