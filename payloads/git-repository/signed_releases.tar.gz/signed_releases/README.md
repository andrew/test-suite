# Signed Releases Repository

This repository contains GPG-signed annotated tags (releases).
